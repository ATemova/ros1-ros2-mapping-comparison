# Delta: fixes from the first CI run on real ROS

Apply on top of branch v0.2-experimental-design (commit 0c1c6ab).

## Modified
- .github/workflows/ci.yml
- .gitignore
- CHANGELOG.md
- docs/metrics.md
- experiments/common.sh
- metrics/analyze_run.py
- metrics/compare_groups.py
- metrics/latency_analysis.py
- tests/test_trajectory_latency.py

## Deleted
- results/raw/ (all committed local test runs)
- results/reports/synthetic_test/
