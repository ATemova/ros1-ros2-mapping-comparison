# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- Floor-plan references: `experiments/floorplan_to_map.py` turns a plan image into an occupancy grid (scale from metres per pixel or one measured distance, crop, room seeds, wall surfaces only); `map_quality.py register` places it in a bag's SLAM map frame (full rotation search, coarse to fine), reports the fit, warns about near-symmetric alternatives and writes an overlay PNG.
- Release gate: the *Release images* workflow first checks the milestone named like the release and every earlier version milestone; with open issues it turns the release back into a draft and publishes nothing. `docs/release.md` describes the milestones and the release checklist.

## [0.3.0] - 2026-11-05

### Added

- arm64 support: Dockerfiles build for amd64 and arm64; CI runs ROS1, ROS2 (Humble and Jazzy with Fast DDS) and the Docker end-to-end job on `ubuntu-24.04-arm` as well; every run records `arch`, run IDs end with it, and runs of different architectures are never pooled (`--arch` filter, `--group-by arch`).
- Release workflow (`.github/workflows/images.yml`): on each published release, builds the three images for amd64 and arm64 on digest-pinned bases, pushes them to GHCR, smoke-tests both architectures and attaches `images.lock`; `make pull VERSION=<tag>` uses them locally.
- Base-image pinning: `docker/build.sh` (used by `make` and `run_matrix.sh`) and `docker/lock.sh`; `make lock` writes `docker/base-images.lock` with multi-arch digests.
- Data-format contract: JSON Schemas in `schemas/` for `run_meta`, `run_metrics`, `run_manifest` and `effective_params`; `schema_version` in every file; `experiments/validate_runs.py` (standard library) and `make validate`; contract tests that validate the real writers' output; CI validates every run it produces. `docs/data-format.md` defines the versioning policy.
- `metrics/sample_size.py` and `make sample-size`: runs per group needed for each comparison from pilot runs (exact t-test power, matching statsmodels, adjusted for the Mann-Whitney test) and the smallest difference detectable with the planned number of runs.
- `run_manifest.json` records the image's registry digests and pinned base image.
- `docs/hardware.md` (robot, sensor and environment template with publication checklist) and `docs/reproducibility.md`.

### Changed

- GitHub Actions moved to their Node 24 majors (`checkout@v7`, `setup-python@v7`, `upload-artifact@v7`, `download-artifact@v8`); runners pinned to `ubuntu-24.04` instead of `ubuntu-latest`.
- `compare_groups.py` run selection is shared with `sample_size.py` (`add_selection_args`, `load_groups`); map consistency in reports uses exactly the runs the report selected.

## [0.2.0] - 2026-10-31

Complete experiment pipeline; still no final results. Both stacks now run the same SLAM
algorithm with identical, verified parameters on identical recorded input, repeated and
compared statistically. New metrics cover per-process resources, latency, trajectory error
and map accuracy. The comparison extends to ROS2 middlewares (Fast DDS, Cyclone DDS, Zenoh),
ROS2 Humble vs Jazzy and stress conditions. Runs are reproducible through the Makefile, with
per-run manifests and generated reports. CI replays a synthetic bag with ground truth through
ROS1 and through ROS2 Humble and Jazzy with every RMW.

### Fixed (found by the first CI runs on real ROS)

- ROS2 map saving: when slam_toolbox's `save_map` service does not write the map (its internal `map_saver_cli` gives up after 2 s, seen with Fast DDS on Jazzy), the runner retries with `map_saver_cli` directly (10 s timeout, transient-local subscription).
- `time_to_first_map_s` used the ROS-clock receive time of the first scan, which is 0 when scans arrive before the first `/clock` message; it now uses the first scan's header stamp. Other ROS-clock metrics skip events received before `/clock`.
- Map/TF latency, map period and jitter now only use events while input is flowing (up to 1 s after the last scan); maps published after the bag ended inflated p95 latency to seconds. Wall-clock map period and jitter added to the summary (slam_toolbox on ROS2 runs its map timer on wall time).
- Maps saved by ROS1 `map_saver` record an absolute image path; `map_quality.load_map` now falls back to the file next to the `.yaml` when that path does not exist (moved run folders, CI artifacts), which broke the report's map figure. A failing figure no longer aborts the report.
- CI jobs start from an empty `results/` folder, and run outputs (`results/raw/`, `results/reports/`, `results/report.md`) are git-ignored; locally committed test runs had broken the verification step.

Experimental design: same algorithm and parameters on both stacks, identical recorded input, repeated runs with statistics.

### Added

- Shared `config/slam_toolbox.yaml` loaded unchanged by both stacks: ROS1 via `rosparam load`, ROS2 as a parameter dict.
- `slam_toolbox` (synchronous) on ROS1 Noetic, selected with `ALGO=slam_toolbox` (new default); GMapping kept as a ROS1-only baseline with real GMapping parameters in `config/gmapping.yaml`.
- Bag replay mode: `BAG=<bag>` replays recorded input with `--clock` / `use_sim_time`; ROS2 playback uses `config/qos_overrides.yaml`.
- Bag tools: `experiments/record_bag.sh`, `experiments/convert_bag.sh` (ROS1 ⇄ ROS2 via `rosbags`, Humble-compatible output), `experiments/inspect_bag.py` (rejects bags recorded while SLAM was running), `experiments/make_synthetic_bag.py` (deterministic test bag).
- `experiments/run_matrix.sh`: repeated, counterbalanced ROS1/ROS2 replay runs in fresh containers, optional resource pinning, batch report in `results/reports/<tag>/`.
- `run_meta.json` per run (stack, algorithm, mode, bag, rate, tag, map received, exit status, git commit, host).
- `metrics/compare_groups.py` and `metrics/stats_utils.py`: mean ± 95% CI, Mann-Whitney U (exact / normal with tie correction), Cliff's delta; refuses to mix conditions.
- Unit tests for the statistics (`tests/test_stats.py`), checked against scipy.
- `docs/parameter_mapping.md`: GMapping ↔ slam_toolbox ↔ ROS1/ROS2 parameter table, generated by `experiments/check_params.py`, which also validates parameter names, types and GMapping alignment (CI fails if the table is stale).
- Runtime parameter verification: each run dumps the parameters the node actually holds (`params_dump.yaml`, `effective_params.json`, `experiments/dump_params.py`) and fails on a mismatch; `compare_groups.py` reports whether effective parameters are identical across all runs (`--require-identical-params`).
- Automatic map saving before shutdown: ROS1 `map_saver`, ROS2 `/slam_toolbox/save_map`, plus `/slam_toolbox/serialize_map` on both; rendered `map.png`.
- Per-process metrics: `cpu_memory_logger.py` groups processes into roles (SLAM node, middleware, launch, bag player, latency logger) and logs CPU/RSS per role (`proc_metrics.csv`) and per-interface network counters (`net_io.csv`).
- `metrics/ros_latency_logger.py` (was a placeholder): records scan, map and TF events on ROS1 (rospy) and ROS2 (rclpy) with the same QoS as SLAM.
- `metrics/latency_analysis.py`: scan drop rate (vs. bag count and from stamp gaps), scan→map and scan→TF-correction latency, map update period and jitter, map age, time to first map.
- `metrics/trajectory.py`: online trajectory export (`trajectory.tum`) and ATE/RPE with evo semantics (validated against evo 1.38).
- `metrics/map_quality.py`: map alignment and accuracy against a reference (cell accuracy, wall F1, wall error, completeness, IoU) and pairwise cross-run consistency.
- `metrics/analyze_run.py`: per-run `run_metrics.json`; runs automatically at the end of each experiment.
- Synthetic bag ships ground truth: `synthetic.groundtruth.tum` and `synthetic.reference.yaml/.pgm`, used automatically.
- Two-machine runs: `ROLE=slam` / `ROLE=player`.
- `experiments/bag_info.py` (scan count of a bag), `docs/metrics.md`, tests for map quality, trajectory, latency and run analysis.
- ROS2 middleware comparison: `RMW=fastrtps|cyclonedds|zenoh` (Zenoh router started automatically); `rmw` and `variant` recorded per run.
- ROS2 Jazzy alongside Humble: `docker/Dockerfile.ros2` takes `ROS_DISTRO`; the launch file configures and activates slam_toolbox's lifecycle node on Jazzy and later.
- Stress conditions: `CPU_SET` (taskset) natively, `CPUS` / `CPU_SET` / `MEMORY` container limits in `run_matrix.sh`; the applied cgroup/affinity limits are recorded and form the run `condition`. Synthetic bags gain `--path loop` (long runs), `--scan-hz` and `--beams`. SLAM RSS growth and trend metrics.
- `Makefile`: `make experiment|matrix|rmw|distros|stress|long|report|check|sample-bag|dataset|images|synthetic`.
- `run_manifest.json` per run (`experiments/write_manifest.py`): git commit and dirty flag, Docker image tag and id, sha256 of parameters, launch file, QoS overrides and bag (cached), ROS package versions, Python libraries, host, limits, ROS/DDS/Zenoh environment.
- `metrics/make_report.py`: `results/reports/<tag>/report.md` and `results/report.md` with setup, statistics, figures (metric distributions, SLAM CPU/RSS timeline, trajectories, maps), map consistency, provenance and run links.
- Kruskal-Wallis test and Holm-adjusted p-values for three or more groups (`stats_utils.py`, validated against scipy).
- Sample-bag path for CI: `experiments/cut_bag.py`, `experiments/fetch_sample_bag.sh`, repository variables `SAMPLE_BAG_URL` / `SAMPLE_BAG_SHA256`.
- Dataset packaging for Zenodo (`experiments/package_dataset.sh`), `CITATION.cff`, `.zenodo.json`, `docs/dataset.md`.
- CI: ROS2 replay matrix over Humble/Jazzy × Fast DDS/Cyclone DDS/Zenoh, RMW and distro comparisons and a full report artifact, Docker end-to-end job through `make` (plus the sample bag when configured), Jazzy image build.
- CI: synthetic bag job, ROS1/ROS2 replay runs that must produce a map, cross-stack comparison in the job summary, unit tests, bag tooling check in the ROS2 image.

### Changed

- `run_ros1.sh` / `run_ros2.sh` share `experiments/common.sh`. Launched processes run in their own process groups and are stopped together (SIGINT, then SIGTERM, then SIGKILL), so no node outlives a run.
- Runs fail when the SLAM package is missing or the SLAM node does not come up, instead of continuing without SLAM. The ROS2 launch no longer falls back to a log message.
- CPU/memory logging is mandatory: missing `psutil`, an early logger exit or an empty `cpu_mem.csv` fails the run. In v0.1.0 the logger only started after the launch check, so a ROS1 launch that died early left a run folder with parameters but no `cpu_mem.csv`.
- `run_meta.json` records `map_saved`, `pose_graph_saved`, `params_ok`, `metrics_samples`.
- ROS2 image adds `ros-humble-nav2-map-server` (needed by `/slam_toolbox/save_map`).
- `compare_groups.py` adds every headline metric from `run_metrics.json` present in all runs, excludes player runs, adds `role` to the run condition, and formats values with precision matched to their scale.
- `run_matrix.sh` runs any list of variants (`VARIANTS="ros1 ros2:humble:cyclonedds ros2:jazzy:zenoh"`), rotates their order every round, passes image and git provenance into each run, and generates the full report.
- `compare_groups.py` compares any grouping (`--group-by stack|rmw|ros_distro|variant|condition|rate|algo`) against a baseline, accepts comma-separated filters, and reports a single group descriptively.
- `map_quality.py consistency` pairs maps by variant (or any run property).
- Run IDs include the variant (`<timestamp>_ros2-humble-fastrtps`), so parallel runs never collide.
- Images are tagged by distribution: `ros1-mapping:noetic`, `ros2-mapping:humble`, `ros2-mapping:jazzy`.
- ROS2 image ships `rosbags`; ROS1 image ships `ros-noetic-slam-toolbox`.

### Removed

- `ros1/params/mapping.yaml` and `ros2/params/mapping.yaml` (replaced by `config/`). The ROS1 file was never loaded and used non-GMapping parameter names.
- v0.1.0 pipeline test runs in `results/raw/` (no metadata; the ROS1 ones had no `cpu_mem.csv`).

## [0.1.0] - 2026-10-16

First public release of the experimental framework. Experiments and analysis are still in progress; this release contains no final results.

### Added

- ROS1 Noetic mapping pipeline: GMapping launch file (`ros1/launch/mapping.launch`) subscribing to `/scan`, and a parameter file (`ros1/params/mapping.yaml`).
- ROS2 Humble mapping pipeline: `slam_toolbox` (synchronous) launch file (`ros2/launch/mapping.launch.py`) with parameter file (`ros2/params/mapping.yaml`). Falls back to a log message when `slam_toolbox` is not installed so the pipeline can be smoke-tested.
- Experiment runners `experiments/run_ros1.sh` and `experiments/run_ros2.sh`: timestamped output directories under `results/raw/`, automatic ROS sourcing, launch by file path (no catkin/colcon build needed), startup validation of the mapping process, parameter archiving, configurable `DURATION`, and process cleanup on exit.
- Experiment protocol notes (`experiments/notes.md`).
- System-wide CPU and memory logger (`metrics/cpu_memory_logger.py`) writing `cpu_mem.csv`.
- Metric summary (`metrics/summarize_metrics.py`) and ROS1-vs-ROS2 run comparison (`metrics/compare_runs.py`) reporting average, median, minimum and maximum CPU and memory, with validation for missing, empty or malformed CSV files.
- Plotting scripts for CPU (`plots/plot_cpu.py`), memory (`plots/plot_memory.py`) and occupancy-grid maps (`plots/plot_maps.py`).
- Dockerfiles for ROS1 Noetic and ROS2 Humble environments.
- GitHub Actions CI: shell/Python/YAML linting, analysis pipeline smoke test, ROS1 and ROS2 container smoke runs, Docker image builds.
- Root `requirements.txt` pointing to `metrics/requirements.txt`.
- `CHANGELOG.md`.

### Changed

- `.gitignore` extended for Python, ROS1 (catkin), ROS2 (colcon), ROS bags (`*.bag`, `*.db3`, `*.mcap`) and large generated result files.
- README: version/status badge, "Requirements" and "Repository structure" sections, known limitations; the "Recent Improvements" list moved into this changelog.
- `metrics/compare_runs.py` marked executable.

[Unreleased]: https://github.com/ATemova/ros1-ros2-mapping-comparison/compare/v0.3.0...HEAD
[0.3.0]: https://github.com/ATemova/ros1-ros2-mapping-comparison/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/ATemova/ros1-ros2-mapping-comparison/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/ATemova/ros1-ros2-mapping-comparison/releases/tag/v0.1.0

