# Delta: better metrics + quantitative map quality (v0.2 step 3)

Apply on top of step 2 (v0.2-bugfixes).

## Added
- docs/metrics.md
- experiments/bag_info.py
- metrics/analyze_run.py
- metrics/latency_analysis.py
- metrics/map_quality.py
- metrics/trajectory.py
- tests/test_analyze_run.py
- tests/test_map_quality.py
- tests/test_trajectory_latency.py

## Modified
- .github/workflows/ci.yml
- CHANGELOG.md
- README.md
- docker/Dockerfile.ros1
- docker/Dockerfile.ros2
- experiments/common.sh
- experiments/make_synthetic_bag.py
- experiments/notes.md
- experiments/run_matrix.sh
- metrics/README.md
- metrics/compare_groups.py
- metrics/cpu_memory_logger.py
- metrics/requirements.txt
- metrics/ros_latency_logger.py

## Deleted
- (none)
