# Delta: scope extensions + reproducibility (v0.2 step 4)

Apply on top of step 3 (v0.2-metrics-map-quality).

## Added
- .zenodo.json
- CITATION.cff
- Makefile
- docs/dataset.md
- experiments/cut_bag.py
- experiments/fetch_sample_bag.sh
- experiments/package_dataset.sh
- experiments/write_manifest.py
- metrics/make_report.py
- tests/test_compare_groups.py

## Modified
- .github/workflows/ci.yml
- .gitignore
- CHANGELOG.md
- README.md
- docker/Dockerfile.ros2
- docs/metrics.md
- experiments/check_params.py
- experiments/common.sh
- experiments/dump_params.py
- experiments/make_synthetic_bag.py
- experiments/notes.md
- experiments/run_matrix.sh
- experiments/write_meta.py
- metrics/README.md
- metrics/analyze_run.py
- metrics/compare_groups.py
- metrics/cpu_memory_logger.py
- metrics/map_quality.py
- metrics/stats_utils.py
- ros2/launch/mapping.launch.py

## Deleted
- (none)
